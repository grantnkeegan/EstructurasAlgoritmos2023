// El segundo intento del MaxHeap.

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <stdexcept>
#include <stack>
#include <list>
#include "ConvertidorIP.h"
#include "MaxHeap.h"
#include "Registro.h"
//#include "HeapSort.h"
#include "Registro.h"
using namespace std;

template <class T>
MaxHeap<T>::MaxHeap(ifstream "bitacora.txt", int max) {
  MaxSize = max
}